#include "buffer.h"

void buffer_insert(uint8_t *buffer, uint8_t start, uint8_t length, uint64_t value)
{
}

uint64_t buffer_extract(uint8_t *buffer, uint8_t start, uint8_t length)
{
}
