#include "unity.h"
#include "buffer.h"

void setUp(void) {}

void tearDown(void) {}

int main(void)
{
    UNITY_BEGIN();

    return UNITY_END();
}
